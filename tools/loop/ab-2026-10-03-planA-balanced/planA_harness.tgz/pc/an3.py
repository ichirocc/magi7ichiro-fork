import csv,re,sys
from collections import defaultdict
src=open('an.py').read().replace("rows=[r for r in csv.reader(open(sys.argv[1])) if len(r)>=28]","rows=[r for r in csv.reader(open(sys.argv[1])) if len(r)>=28 and r[4]!='0']")
src=src.replace("rows=[r for r in csv.reader(open(sys.argv[1])) if len(r)>=28 and r[4]!='0']","rows=_rows")
_raw=[r for r in csv.reader(open(sys.argv[1])) if len(r)>=28 and r[4]!='0']
_g=defaultdict(list)
for r in _raw: _g[(r[0],r[1],r[2],r[3])].append(r)
_rows=[]
_best={}
for k,v in _g.items():
    if len({(r[4],r[5]) for r in v})==8: _best[k[:3]]=v
for v in _best.values():
    last={}
    for r in v: last[(r[4],r[5])]=r
    _rows+=sorted(last.values(),key=lambda r:v.index(r))
print('complete boards',len(_best))
exec(src)
for f in ['golden','sample','blocked_covu','sept2026']: stats(lambda r,f=f:r[1]==f,"FX "+f)
P=defaultdict(list)
for r in rows: P[(r[0],r[1],r[2],r[4])].append(r)
fw=sw=e=0; onF=[0,0,0]; onS=[0,0,0]
for k,v in P.items():
    if len(v)<2: continue
    a,b=v[0],v[1]; wa,wb=float(a[24]),float(b[24])
    if wb<wa: sw+=1
    elif wa<wb: fw+=1
    else: e+=1
    on,off=(a,b) if a[5]=='on' else (b,a); c=onF if a[5]=='on' else onS
    d=float(on[24])-float(off[24]); c[0 if d<0 else 1 if d>0 else 2]+=1
print(f"順序: 先が勝ち{fw} 後が勝ち{sw} 分{e} | ON先行時 ON勝/負/分{onF} ON後行時{onS}")
for arm in ['off','on']:
    ad=[int(m.group(1)) for r in rows if r[5]==arm for m in [re.search(r'採用(\d+)束',','.join(r[28:]))] if m]
    print(f"C1LNS採用 {arm}: 採用>0の走行{sum(x>0 for x in ad)}/{len(ad)} 総束{sum(ad)}")
