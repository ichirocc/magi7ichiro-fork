package com.magi.app.v6
import com.magi.app.model.StateParser
import kotlinx.coroutines.runBlocking
import java.io.File
fun main(args: Array<String>) {
    val res = File(args[0]); val out = File(args[1]); val fx = args[2]; val budget = args[3].toInt(); val want = File(args[4]).readLines().map{it.split(",")}.filter{it[0]==budget.toString()&&it[1]==fx}
    val fos = java.io.FileOutputStream(out, true)
    fun emit(line: String) { fos.write((line + "\n").toByteArray()); fos.flush(); fos.fd.sync() }
    val doneRows = if (out.exists()) out.readLines().map { it.split(",") }.filter { it.size >= 28 && it[0] == budget.toString() && it[1] == fx && it[4] != "0" } else emptyList()
    fun complete(seed: String) = doneRows.filter { it[2] == seed }.groupBy { it[3] }.values.any { g -> (1..4).all { r -> listOf("on", "off").all { a -> g.any { it[4] == r.toString() && it[5] == a } } } }
    val st = StateParser.parse(File(res, "${fx}_state.json").readText())!!
    val p1 = java.io.FileOutputStream(File(out.path + ".p1"), true)
    var warmed = false
    for ((wi, wl) in want.withIndex()) { val seed = wl[2].toInt(); val wantH = wl[3].toInt(); val remOrig = wl[4].toLong()
        if (complete(seed.toString())) continue
        waitload(); C1JointLnsPolish.deltaChildEvalDefault = false
        var cap: PostCapture.Snap? = null
        PostCapture.hook = { cap = it }
        runBlocking { V6FinalPort.handleOptimize(st, st.schedule.toIntArray2D(), secondsRaw = budget, workers = 4, allowImpossible = true, seed = seed.toLong() * 7919L) }
        PostCapture.hook = null
        val sn = cap
        val h = sn?.board?.contentDeepHashCode() ?: 0
        p1.write("$budget,$fx,$seed,$h,$wantH,${sn?.remMs},$remOrig\n".toByteArray()); p1.flush(); p1.fd.sync()
        if (sn == null || sn.e0b) continue
        val rem = if (h == wantH) remOrig else sn.remMs
        val pat = if (wi % 2 == 0) listOf(true, false, false, true) else listOf(false, true, true, false)
        val seq = ArrayList<Pair<Int, Boolean>>()
        if (!warmed) { warmed = true; seq.add(0 to true); seq.add(0 to false) }
        for (rep in 1..4) { val f = pat[rep - 1]; seq.add(rep to f); seq.add(rep to !f) }
        for ((rep, on) in seq) {
            waitload(); C1JointLnsPolish.deltaChildEvalDefault = on
            val n19a = nice19Active(); val t0 = EngineClock.nowMs(); val dl = t0 + rem
            val post = V6HotfixPasses.runPostOptimization(sn.state, sn.board.copy2D(), sn.tech, shouldStop = { EngineClock.nowMs() >= dl }, deadlineMs = dl, params = sn.params)
            val tP = EngineClock.nowMs()
            val extraMs = minOf(dl - tP, sn.reserveMs)
            val canExtra = !sn.stagnated && post.report.total > 0
            var fin = post.report; var fs = post.schedule; var ran = false; var imp = false
            if (extraMs >= 5_000 && canExtra) { ran = true
                val xdl = tP + extraMs
                val ex = runBlocking { V6NativeOptimizer.optimize(sn.state, post.schedule, sn.opts.copy(algorithm = V6Algorithm.ALNS, totalBudgetSec = (extraMs / 1000L).toInt().coerceAtLeast(5), workers = sn.opts.workers.coerceAtMost(HypothesisPlanning.MAX_HYPOTHESES)), { EngineClock.nowMs() >= xdl }) }
                imp = betterReport(ex.report, post.report); if (imp) { fin = ex.report; fs = ex.schedule }
            }
            val tE = EngineClock.nowMs()
            val tl = post.logs.firstOrNull { it.tag == "POST" && it.message.startsWith("後処理タイミング") }?.message ?: ""
            val m = Regex("総(\\d+)ms: HF80=(\\d+)ms HF67=(\\d+)ms HF66=(\\d+)ms .*?=(\\d+)ms C1共同LNS=(\\d+)ms 個人共同LNS=(\\d+)ms 最終検査\\+HF70=(\\d+)ms").find(tl)?.groupValues?.drop(1)?.joinToString(",") ?: ",,,,,,,"
            val cut = post.logs.any { it.tag == "POST" && it.message.startsWith("予算超過") }
            val lns = post.logs.filter { it.tag == "C1JointLNS" }.distinctBy { it.message }.joinToString(" / ") { it.message.replace(",", ";") }
            val tail = post.logs.filter { it.tag in setOf("PersonalJointLNS","ComponentRepair","RestZeroLNS","CovORelief") }.joinToString(" | ") { it.tag + ":" + it.message.replace(",", ";") }
            val line = "$budget,$fx,$seed,$h,$rep,${if (on) "on" else "off"},$rem,${sn.reserveMs},${sn.stagnated},$m,$cut,${post.report.hard},${post.report.weightedScore},$ran,$imp,${tE - tP},${fin.hard},${fin.weightedScore},${fin.total},${fs.contentDeepHashCode()},${tE - t0},$lns,$tail,nice19=${if (n19a || nice19Active()) 1 else 0}"
            emit(line); System.err.println(line)
        }
    }
    fos.close(); p1.close()
}
var needLow = true
fun niceOf(pid: Long): Int = try { File("/proc/$pid/stat").readText().substringAfterLast(")").trim().split(" ")[16].toInt() } catch (e: Exception) { 0 }
fun heavy() = ProcessHandle.allProcesses().filter { it.pid() != ProcessHandle.current().pid() }.filter { val c = it.info().commandLine().orElse(""); (c.contains("dotnet") && !c.contains("VBCSCompiler")) || c.contains("/java ") || c.startsWith("java ") }.toList()
fun nice19Active() = heavy().any { niceOf(it.pid()) >= 19 }
fun waitload() {
    while (true) {
        val la = File("/proc/loadavg").readText().split(" ")[0].toDouble()
        val hs = heavy(); val others = hs.count { niceOf(it.pid()) < 19 }.toLong(); val n19 = hs.size > others
        if (others == 0L && (!needLow || la < 1.5 || n19)) { needLow = false; return }
        if (others > 0L) needLow = true
        System.err.println("waitload la=$la others=$others"); Thread.sleep(30000)
    }
}
