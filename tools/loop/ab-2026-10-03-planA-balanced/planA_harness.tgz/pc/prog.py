import csv,sys
from collections import defaultdict
want=[l.split(',') for l in open(sys.argv[1]) if l.strip()]
g=defaultdict(set)
try:
  for r in csv.reader(open(sys.argv[2])):
    if len(r)>=28 and r[4]!='0': g[(r[0],r[1],r[2],r[3])].add((r[4],r[5]))
except FileNotFoundError: pass
full={(k[0],k[1],k[2]) for k,v in g.items() if len(v)==8}
done=sum((w[0],w[1],w[2]) in full for w in want)
open(sys.argv[3],'w').write(f"boards done {done} / {len(want)}  (8 runs per board)\n")
