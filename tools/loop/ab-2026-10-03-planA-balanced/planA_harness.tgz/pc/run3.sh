#!/bin/bash
# Resumable: re-run the same command after restart. Never truncates out3.csv.
cd /tmp/claude-0/-home-user/9af34729-1ee3-5dcc-8433-ea3a204d0dda/scratchpad/pa
exec 9>pc/run3.lock; flock -n 9 || { echo "already running"; exit 0; }
L=/root/.cache/magi-host-libs
( while true; do python3 pc/prog.py pc/want.csv pc/out3.csv pc/progress.txt; sleep 60; done ) & PP=$!
for b in 60 120; do for f in golden sample blocked_covu sept2026; do
 LANG=C.utf8 timeout 12000 java -Xmx3g -cp "$L/kotlin-stdlib-2.3.21.jar:$L/kotlinx-coroutines-core-jvm-1.8.1.jar:$L/json-20240303.jar:q2/main:q2/pc2" com.magi.app.v6.PC2Kt pc/res pc/out3.csv $f $b pc/want.csv 2>>pc/err3.log
done; done
python3 pc/prog.py pc/want.csv pc/out3.csv pc/progress.txt; kill $PP
echo DONE >> pc/err3.log
