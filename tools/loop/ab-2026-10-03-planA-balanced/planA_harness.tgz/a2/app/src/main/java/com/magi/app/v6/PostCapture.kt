package com.magi.app.v6
import com.magi.app.model.MagiState
object PostCapture {
    class Snap(val state: MagiState, val board: Array<IntArray>, val remMs: Long, val reserveMs: Long, val stagnated: Boolean, val e0b: Boolean, val opts: V6OptimizerOptions, val params: V6HotfixPasses.PostOptimizationParams, val tech: String)
    @Volatile var hook: ((Snap) -> Unit)? = null
}
